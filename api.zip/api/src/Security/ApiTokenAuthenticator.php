<?php

namespace App\Security;

use App\Entity\Utilisateur;
use App\Repository\UtilisateurRepository;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Security\Core\Authentication\Token\TokenInterface;
use Symfony\Component\Security\Core\Exception\AuthenticationException;
use Symfony\Component\Security\Http\Authenticator\AbstractAuthenticator;
use Symfony\Component\Security\Http\Authenticator\Passport\Passport;
use Symfony\Component\Security\Http\Authenticator\Passport\SelfValidatingPassport;
use Symfony\Component\Security\Http\Authenticator\Passport\Badge\UserBadge;
use Symfony\Component\PasswordHasher\Hasher\UserPasswordHasherInterface;
use Symfony\Component\Security\Http\Authentication\AuthenticationSuccessHandlerInterface;
use Symfony\Component\Security\Http\Authentication\AuthenticationFailureHandlerInterface;

class ApiTokenAuthenticator extends AbstractAuthenticator
{
    private $userRepository;
    private $passwordHasher;

    public function __construct(
        UtilisateurRepository $userRepository,
        UserPasswordHasherInterface $passwordHasher
    ) {
        $this->userRepository = $userRepository;
        $this->passwordHasher = $passwordHasher;
    }

    private function isProtectedRoute(Request $request): bool
    {
        $path = $request->getPathInfo();
        $isApiRoute = str_starts_with($path, '/api/');
        $isPublicRoute = in_array($path, ['/api/login', '/api/register']);
        $isGetRequest = $request->getMethod() === 'GET';
        
        return $isApiRoute && !$isPublicRoute && !$isGetRequest;
    }

    public function supports(Request $request): ?bool
    {
        return $request->getPathInfo() === '/api/login' || $this->isProtectedRoute($request);
    }

    public function authenticate(Request $request): Passport
    {
        if ($request->getPathInfo() === '/api/login') {
            $data = json_decode($request->getContent(), true);
            if (!isset($data['email']) || !isset($data['motdepasse'])) {
                throw new AuthenticationException('Email and password are required');
            }

            return new SelfValidatingPassport(
                new UserBadge($data['email'], function($email) use ($data) {
                    $user = $this->userRepository->findOneBy(['email' => $email]);
                    if (!$user) {
                        throw new AuthenticationException('User not found');
                    }
                    
                    if (!$this->passwordHasher->isPasswordValid($user, $data['motdepasse'])) {
                        throw new AuthenticationException('Invalid password');
                    }
                    
                    return $user;
                })
            );
        }

        // For protected routes, check Authorization header
        $authHeader = $request->headers->get('Authorization');
        if (!$authHeader) {
            throw new AuthenticationException('Authorization header required');
        }

        $token = str_replace('Bearer ', '', $authHeader);
        return new SelfValidatingPassport(
            new UserBadge($token, function($token) {
                $user = $this->userRepository->findOneBy(['email' => $token]);
                if (!$user) {
                    throw new AuthenticationException('Invalid token');
                }
                return $user;
            })
        );
    }

    public function onAuthenticationSuccess(Request $request, TokenInterface $token, string $firewallName): ?Response
    {
        if ($request->getPathInfo() === '/api/login') {
            /** @var Utilisateur $user */
            $user = $token->getUser();
            return new JsonResponse([
                'message' => 'Login successful',
                'user' => [
                    'email' => $user->getUserIdentifier(),
                    'roles' => $user->getRoles(),
                    'prenom' => $user->getPrenom(),
                    'nom' => $user->getNom()
                ]
            ]);
        }
        return null; // Let the request continue for other routes
    }

    public function onAuthenticationFailure(Request $request, AuthenticationException $exception): ?JsonResponse
    {
        return new JsonResponse([
            'error' => 'Authentication failed',
            'message' => $exception->getMessage()
        ], 401);
    }
}