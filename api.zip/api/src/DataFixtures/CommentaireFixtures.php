<?php

namespace App\DataFixtures;

use App\Entity\Commentaire;
use App\Entity\Club;
use App\Entity\Utilisateur;
use App\Entity\Evenement;
use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Persistence\ObjectManager;
use Doctrine\Common\DataFixtures\DependentFixtureInterface;

class CommentaireFixtures extends Fixture implements DependentFixtureInterface
{
    public function load(ObjectManager $manager): void
    {
        // Fetch existing clubs and users
        $clubs = $manager->getRepository(Club::class)->findAll();
        $users = $manager->getRepository(Utilisateur::class)->findAll();
        $evenements = $manager->getRepository(Evenement::class)->findAll();

        if (empty($clubs) || empty($users) || empty($evenements)) {
            throw new \Exception('Ensure you have created Clubs, Users, and Evenements before Commentaires');
        }

        $commentaire1 = new Commentaire();
        $commentaire1->setContenu('Super événement!')
                     ->setDateCreation(new \DateTime())
                     ->setClub($clubs[0])
                     ->setAuteur($users[0])
                     ->setOrganisateur($users[0])
                     ->setEvenement($evenements[0]);

        $commentaire2 = new Commentaire();
        $commentaire2->setContenu('Vraiment impressionnant!')
                     ->setDateCreation(new \DateTime())
                     ->setClub($clubs[1])
                     ->setAuteur($users[1])
                     ->setOrganisateur($users[1])
                     ->setEvenement($evenements[1]);

        $manager->persist($commentaire1);
        $manager->persist($commentaire2);
        $manager->flush();
    }

    public function getDependencies(): array
    {
        return [
            ClubFixtures::class,
            UtilisateurFixtures::class,
            EvenementFixtures::class
        ];
    }
}
