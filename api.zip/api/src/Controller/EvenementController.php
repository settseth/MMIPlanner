<?php

namespace App\Controller;

use App\Entity\Evenement;
use App\Repository\EvenementRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Security\Core\Security;
use Symfony\Component\Serializer\SerializerInterface;
use Symfony\Component\Validator\Validator\ValidatorInterface;

#[Route('/api/evenements')]
class EvenementController extends AbstractController
{
    #[Route('', methods: ['GET'])]
    public function listEvenements(EvenementRepository $evenementRepository, SerializerInterface $serializer): JsonResponse
    {
        $evenements = $evenementRepository->findAll();
        return new JsonResponse(
            $serializer->serialize($evenements, 'json', ['groups' => 'evenement:read']), 
            JsonResponse::HTTP_OK, 
            [], 
            true
        );
    }

    #[Route('', methods: ['POST'])]
    public function createEvenement(
        Request $request, 
        EntityManagerInterface $entityManager, 
        SerializerInterface $serializer,
        ValidatorInterface $validator,
        Security $security
    ): JsonResponse {
        try {
            // Récupérer l'utilisateur connecté
            $currentUser = $security->getUser();
            if (!$currentUser) {
                return new JsonResponse([
                    'error' => 'Utilisateur non authentifié'
                ], JsonResponse::HTTP_UNAUTHORIZED);
            }

            $evenement = $serializer->deserialize(
                $request->getContent(), 
                Evenement::class, 
                'json'
            );

            // Forcer l'organisateur à l'utilisateur connecté
            $evenement->setOrganisateur($currentUser);

            // Validate the evenement
            $errors = $validator->validate($evenement);
            if (count($errors) > 0) {
                return new JsonResponse(
                    $serializer->serialize($errors, 'json'),
                    JsonResponse::HTTP_BAD_REQUEST
                );
            }

            // Set creation date
            $evenement->setDateCreation(new \DateTime());

            $entityManager->persist($evenement);
            $entityManager->flush();

            return new JsonResponse(
                $serializer->serialize($evenement, 'json', ['groups' => 'evenement:read']), 
                JsonResponse::HTTP_CREATED
            );
        } catch (\Exception $e) {
            return new JsonResponse([
                'error' => 'Error creating evenement',
                'message' => $e->getMessage()
            ], JsonResponse::HTTP_BAD_REQUEST);
        }
    }

    #[Route('/{id}', methods: ['GET'])]
    public function getEvenement(
        Evenement $evenement, 
        SerializerInterface $serializer
    ): JsonResponse {
        return new JsonResponse(
            $serializer->serialize($evenement, 'json', ['groups' => 'evenement:read']), 
            JsonResponse::HTTP_OK, 
            [], 
            true
        );
    }

    #[Route('/{id}', methods: ['PUT'])]
    public function updateEvenement(
        Evenement $evenement, 
        Request $request, 
        EntityManagerInterface $entityManager, 
        SerializerInterface $serializer,
        ValidatorInterface $validator
    ): JsonResponse {
        try {
            $updatedEvenement = $serializer->deserialize(
                $request->getContent(), 
                Evenement::class, 
                'json',
                ['object_to_populate' => $evenement]
            );

            // Validate the evenement
            $errors = $validator->validate($updatedEvenement);
            if (count($errors) > 0) {
                return new JsonResponse(
                    $serializer->serialize($errors, 'json'),
                    JsonResponse::HTTP_BAD_REQUEST
                );
            }

            $entityManager->flush();

            return new JsonResponse(
                $serializer->serialize($updatedEvenement, 'json', ['groups' => 'evenement:read']), 
                JsonResponse::HTTP_OK
            );
        } catch (\Exception $e) {
            return new JsonResponse([
                'error' => 'Error updating evenement',
                'message' => $e->getMessage()
            ], JsonResponse::HTTP_BAD_REQUEST);
        }
    }

    #[Route('/{id}', methods: ['DELETE'])]
    public function deleteEvenement(
        Evenement $evenement, 
        EntityManagerInterface $entityManager
    ): JsonResponse {
        try {
            $entityManager->remove($evenement);
            $entityManager->flush();

            return new JsonResponse(null, JsonResponse::HTTP_NO_CONTENT);
        } catch (\Exception $e) {
            return new JsonResponse([
                'error' => 'Error deleting evenement',
                'message' => $e->getMessage()
            ], JsonResponse::HTTP_BAD_REQUEST);
        }
    }
}