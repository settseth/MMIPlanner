<?php

namespace App\DataFixtures;

use App\Entity\Utilisateur;
use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Persistence\ObjectManager;
use Symfony\Component\PasswordHasher\Hasher\UserPasswordHasherInterface;
use Symfony\Component\Security\Core\User\PasswordAuthenticatedUserInterface;
use Symfony\Component\Security\Core\User\UserInterface;

class UtilisateurFixtures extends Fixture
{
    private $passwordHasher;

    public function __construct(UserPasswordHasherInterface $passwordHasher)
    {
        $this->passwordHasher = $passwordHasher;
    }

    public function load(ObjectManager $manager): void
    {
        $user1 = new Utilisateur();
        $user1->setEmail('photographe@example.com')
              ->setPrenom('Jean')
              ->setNom('Dupont')
              ->setEstactif(true)
              ->setRoles(['ROLE_USER'])
              ->setMotdepasse($this->passwordHasher->hashPassword($user1, 'password123'));

        $user2 = new Utilisateur();
        $user2->setEmail('vr_expert@example.com')
              ->setPrenom('Marie')
              ->setNom('Durand')
              ->setEstactif(true)
              ->setRoles(['ROLE_USER'])
              ->setMotdepasse($this->passwordHasher->hashPassword($user2, 'password456'));

        $manager->persist($user1);
        $manager->persist($user2);
        $manager->flush();
    }
}
