<?php

namespace App\Command;

use App\Entity\Utilisateur;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\PasswordHasher\Hasher\UserPasswordHasherInterface;

class UpdateAdminPasswordCommand extends Command
{
    protected static $defaultName = 'app:update-admin-password';
    private $entityManager;
    private $passwordHasher;

    public function __construct(EntityManagerInterface $entityManager, UserPasswordHasherInterface $passwordHasher)
    {
        parent::__construct();
        $this->entityManager = $entityManager;
        $this->passwordHasher = $passwordHasher;
    }

    protected function configure(): void
    {
        $this->setDescription('Updates the admin password.');
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $user = $this->entityManager->getRepository(Utilisateur::class)->findOneBy(['email' => 'admin@eventspace.com']);
        
        if (!$user) {
            $output->writeln('Admin user not found.');
            return Command::FAILURE;
        }

        $hashedPassword = $this->passwordHasher->hashPassword($user, 'admin123');
        $user->setMotdepasse($hashedPassword);

        $this->entityManager->flush();

        $output->writeln('Admin password updated successfully.');

        return Command::SUCCESS;
    }
}
