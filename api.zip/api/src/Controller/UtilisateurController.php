<?php

namespace App\Controller;

use App\Entity\Utilisateur;
use App\Repository\UtilisateurRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Serializer\SerializerInterface;
use Symfony\Component\PasswordHasher\Hasher\UserPasswordHasherInterface;

#[Route('/api/utilisateurs')]
class UtilisateurController extends AbstractController
{
    #[Route('', methods: ['GET'])]
    public function listUtilisateurs(UtilisateurRepository $utilisateurRepository, SerializerInterface $serializer): JsonResponse
    {
        $utilisateurs = $utilisateurRepository->findAll();
        return new JsonResponse(
            $serializer->serialize($utilisateurs, 'json', ['groups' => 'utilisateur:read']), 
            JsonResponse::HTTP_OK, 
            [], 
            true
        );
    }

    #[Route('', methods: ['POST'])]
    public function createUtilisateur(
    Request $request, 
    EntityManagerInterface $entityManager, 
    SerializerInterface $serializer,
    UserPasswordHasherInterface $passwordHasher
): JsonResponse {
    $data = json_decode($request->getContent(), true);
    
    $utilisateur = $serializer->deserialize($request->getContent(), Utilisateur::class, 'json');
    
    // Hash the password
    if (isset($data['motdepasse'])) {
        $hashedPassword = $passwordHasher->hashPassword($utilisateur, $data['motdepasse']);
        $utilisateur->setMotdepasse($hashedPassword);
    }

    $entityManager->persist($utilisateur);
    $entityManager->flush();

    return new JsonResponse($utilisateur, JsonResponse::HTTP_CREATED);
}

    #[Route('/{id}', methods: ['GET'])]
    public function getUtilisateur(Utilisateur $utilisateur, SerializerInterface $serializer): JsonResponse
    {
        return new JsonResponse(
            $serializer->serialize($utilisateur, 'json', ['groups' => 'utilisateur:read']), 
            JsonResponse::HTTP_OK, 
            [], 
            true
        );
    }
}