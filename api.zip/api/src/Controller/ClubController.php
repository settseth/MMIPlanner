<?php

namespace App\Controller;

use App\Entity\Club;
use App\Repository\ClubRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Serializer\SerializerInterface;
use Symfony\Component\Validator\Validator\ValidatorInterface;

#[Route('/api/clubs')]
class ClubController extends AbstractController
{
    #[Route('', methods: ['GET'])]
    public function listClubs(ClubRepository $clubRepository, SerializerInterface $serializer): JsonResponse
    {
        $clubs = $clubRepository->findAll();
        return new JsonResponse(
            $serializer->serialize($clubs, 'json', ['groups' => 'club:read']), 
            JsonResponse::HTTP_OK, 
            [], 
            true
        );
    }

    #[Route('', methods: ['POST'])]
    public function createClub(
        Request $request, 
        EntityManagerInterface $entityManager, 
        SerializerInterface $serializer,
        ValidatorInterface $validator
    ): JsonResponse {
        try {
            $club = $serializer->deserialize(
                $request->getContent(), 
                Club::class, 
                'json'
            );

            // Validate the club
            $errors = $validator->validate($club);
            if (count($errors) > 0) {
                return new JsonResponse(
                    $serializer->serialize($errors, 'json'),
                    JsonResponse::HTTP_BAD_REQUEST
                );
            }

            // Set creation date
            $club->setDateCreation(new \DateTime());

            $entityManager->persist($club);
            $entityManager->flush();

            return new JsonResponse(
                $serializer->serialize($club, 'json', ['groups' => 'club:read']), 
                JsonResponse::HTTP_CREATED,
                [],
                true
            );
        } catch (\Exception $e) {
            return new JsonResponse([
                'error' => 'Error creating club',
                'message' => $e->getMessage()
            ], JsonResponse::HTTP_BAD_REQUEST);
        }
    }

    #[Route('/{id}', methods: ['GET'])]
    public function getClub(Club $club, SerializerInterface $serializer): JsonResponse
    {
        return new JsonResponse(
            $serializer->serialize($club, 'json', ['groups' => 'club:read']), 
            JsonResponse::HTTP_OK, 
            [], 
            true
        );
    }

    #[Route('/{id}', methods: ['PUT'])]
    public function updateClub(
        Club $club, 
        Request $request, 
        EntityManagerInterface $entityManager, 
        SerializerInterface $serializer,
        ValidatorInterface $validator
    ): JsonResponse {
        try {
            $updatedClub = $serializer->deserialize(
                $request->getContent(), 
                Club::class, 
                'json',
                ['object_to_populate' => $club]
            );

            // Validate the club    
            $errors = $validator->validate($updatedClub);
            if (count($errors) > 0) {
                return new JsonResponse(
                    $serializer->serialize($errors, 'json'),
                    JsonResponse::HTTP_BAD_REQUEST
                );
            }

            $entityManager->flush();

            return new JsonResponse(
                $serializer->serialize($updatedClub, 'json', ['groups' => 'club:read']), 
                JsonResponse::HTTP_OK,
                [],
                true
            );
        } catch (\Exception $e) {
            return new JsonResponse([
                'error' => 'Error updating club',
                'message' => $e->getMessage()
            ], JsonResponse::HTTP_BAD_REQUEST);
        }
    }

    #[Route('/{id}', methods: ['DELETE'])]
    public function deleteClub(
        Club $club, 
        EntityManagerInterface $entityManager
    ): JsonResponse {
        try {
            $entityManager->remove($club);
            $entityManager->flush();

            return new JsonResponse(null, JsonResponse::HTTP_NO_CONTENT);
        } catch (\Exception $e) {
            return new JsonResponse([
                'error' => 'Error deleting club',
                'message' => $e->getMessage()
            ], JsonResponse::HTTP_BAD_REQUEST);
        }
    }
}
