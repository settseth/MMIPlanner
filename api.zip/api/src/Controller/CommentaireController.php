<?php

namespace App\Controller;

use App\Entity\Commentaire;
use App\Repository\CommentaireRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Serializer\SerializerInterface;
use Symfony\Component\Validator\Validator\ValidatorInterface;

#[Route('/api/commentaires')]
class CommentaireController extends AbstractController
{
    #[Route('', methods: ['GET'])]
    public function listCommentaires(
        CommentaireRepository $commentaireRepository, 
        SerializerInterface $serializer
    ): JsonResponse {
        $commentaires = $commentaireRepository->findAll();
        
        return new JsonResponse(
            $serializer->serialize($commentaires, 'json', ['groups' => 'commentaire:read']), 
            JsonResponse::HTTP_OK, 
            [], 
            true
        );
    }

    #[Route('', methods: ['POST'])]
    public function createCommentaire(
        Request $request, 
        EntityManagerInterface $entityManager, 
        SerializerInterface $serializer,
        ValidatorInterface $validator
    ): JsonResponse {
        try {
            // Deserialize the request content
            $commentaire = $serializer->deserialize(
                $request->getContent(), 
                Commentaire::class, 
                'json'
            );

            // Validate the commentaire
            $errors = $validator->validate($commentaire);
            if (count($errors) > 0) {
                return new JsonResponse(
                    $serializer->serialize($errors, 'json'),
                    JsonResponse::HTTP_BAD_REQUEST
                );
            }

            // Set creation date
            $commentaire->setDateCreation(new \DateTime());

            $entityManager->persist($commentaire);
            $entityManager->flush();

            return new JsonResponse(
                $serializer->serialize($commentaire, 'json', ['groups' => 'commentaire:read']), 
                JsonResponse::HTTP_CREATED,
                [],
                true
            );
        } catch (\Exception $e) {
            return new JsonResponse([
                'error' => 'Error creating commentaire',
                'message' => $e->getMessage()
            ], JsonResponse::HTTP_BAD_REQUEST);
        }
    }

    #[Route('/{id}', methods: ['GET'])]
    public function getCommentaire(
        Commentaire $commentaire, 
        SerializerInterface $serializer
    ): JsonResponse {
        return new JsonResponse(
            $serializer->serialize($commentaire, 'json', ['groups' => 'commentaire:read']), 
            JsonResponse::HTTP_OK, 
            [], 
            true
        );
    }

    #[Route('/{id}', methods: ['PUT'])]
    public function updateCommentaire(
        Commentaire $commentaire, 
        Request $request, 
        EntityManagerInterface $entityManager, 
        SerializerInterface $serializer,
        ValidatorInterface $validator
    ): JsonResponse {
        try {
            // Deserialize with object population
            $updatedCommentaire = $serializer->deserialize(
                $request->getContent(), 
                Commentaire::class, 
                'json',
                ['object_to_populate' => $commentaire]
            );

            // Validate the commentaire
            $errors = $validator->validate($updatedCommentaire);
            if (count($errors) > 0) {
                return new JsonResponse(
                    $serializer->serialize($errors, 'json'),
                    JsonResponse::HTTP_BAD_REQUEST
                );
            }

            $entityManager->flush();

            return new JsonResponse(
                $serializer->serialize($updatedCommentaire, 'json', ['groups' => 'commentaire:read']), 
                JsonResponse::HTTP_OK,
                [],
                true
            );
        } catch (\Exception $e) {
            return new JsonResponse([
                'error' => 'Error updating commentaire',
                'message' => $e->getMessage()
            ], JsonResponse::HTTP_BAD_REQUEST);
        }
    }

    #[Route('/{id}', methods: ['DELETE'])]
    public function deleteCommentaire(
        Commentaire $commentaire, 
        EntityManagerInterface $entityManager
    ): JsonResponse {
        try {
            $entityManager->remove($commentaire);
            $entityManager->flush();

            return new JsonResponse(null, JsonResponse::HTTP_NO_CONTENT);
        } catch (\Exception $e) {
            return new JsonResponse([
                'error' => 'Error deleting commentaire',
                'message' => $e->getMessage()
            ], JsonResponse::HTTP_BAD_REQUEST);
        }
    }
}
