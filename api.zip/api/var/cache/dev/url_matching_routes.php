<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/api/login' => [[['_route' => 'app_login', '_controller' => 'App\\Controller\\SecurityController::login'], null, ['POST' => 0], null, false, false, null]],
        '/api/register' => [[['_route' => 'app_register', '_controller' => 'App\\Controller\\SecurityController::register'], null, ['POST' => 0], null, false, false, null]],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/api(?'
                    .'|/(?'
                        .'|\\.well\\-known/genid/([^/]++)(*:46)'
                        .'|validation_errors/([^/]++)(*:79)'
                    .')'
                    .'|(?:/(index)(?:\\.([^/]++))?)?(*:115)'
                    .'|/(?'
                        .'|docs(?:\\.([^/]++))?(*:146)'
                        .'|c(?'
                            .'|o(?'
                                .'|ntexts/([^.]+)(?:\\.(jsonld))?(*:191)'
                                .'|mmentaires(?'
                                    .'|/([^/\\.]++)(?:\\.([^/]++))?(*:238)'
                                    .'|(?:\\.([^/]++))?(?'
                                        .'|(*:264)'
                                    .')'
                                    .'|/(?'
                                        .'|([^/\\.]++)(?:\\.([^/]++))?(?'
                                            .'|(*:305)'
                                        .')'
                                        .'|([^/]++)(?'
                                            .'|(*:325)'
                                        .')'
                                    .')'
                                    .'|(*:335)'
                                .')'
                            .')'
                            .'|lubs(?'
                                .'|/([^/\\.]++)(?:\\.([^/]++))?(*:378)'
                                .'|(?:\\.([^/]++))?(?'
                                    .'|(*:404)'
                                .')'
                                .'|/(?'
                                    .'|([^/\\.]++)(?:\\.([^/]++))?(?'
                                        .'|(*:445)'
                                    .')'
                                    .'|([^/]++)(?'
                                        .'|(*:465)'
                                    .')'
                                .')'
                                .'|(*:475)'
                            .')'
                        .')'
                        .'|e(?'
                            .'|rrors/(\\d+)(?:\\.([^/]++))?(*:515)'
                            .'|venements(?'
                                .'|/([^/\\.]++)(?:\\.([^/]++))?(*:561)'
                                .'|(?:\\.([^/]++))?(?'
                                    .'|(*:587)'
                                .')'
                                .'|/(?'
                                    .'|([^/\\.]++)(?:\\.([^/]++))?(?'
                                        .'|(*:628)'
                                    .')'
                                    .'|([^/]++)(?'
                                        .'|(*:648)'
                                    .')'
                                .')'
                                .'|(*:658)'
                            .')'
                        .')'
                        .'|validation_errors/([^/]++)(?'
                            .'|(*:697)'
                        .')'
                        .'|utilisateurs(?'
                            .'|/([^/\\.]++)(?:\\.([^/]++))?(*:747)'
                            .'|(?:\\.([^/]++))?(?'
                                .'|(*:773)'
                            .')'
                            .'|/(?'
                                .'|([^/\\.]++)(?:\\.([^/]++))?(?'
                                    .'|(*:814)'
                                .')'
                                .'|([^/]++)(*:831)'
                            .')'
                            .'|(*:840)'
                        .')'
                    .')'
                .')'
                .'|/_error/(\\d+)(?:\\.([^/]++))?(*:879)'
            .')/?$}sDu',
    ],
    [ // $dynamicRoutes
        46 => [[['_route' => 'api_genid', '_controller' => 'api_platform.action.not_exposed', '_api_respond' => 'true'], ['id'], ['GET' => 0, 'HEAD' => 1], null, false, true, null]],
        79 => [[['_route' => 'api_validation_errors', '_controller' => 'api_platform.action.not_exposed'], ['id'], ['GET' => 0, 'HEAD' => 1], null, false, true, null]],
        115 => [[['_route' => 'api_entrypoint', '_controller' => 'api_platform.action.entrypoint', '_format' => '', '_api_respond' => 'true', 'index' => 'index'], ['index', '_format'], ['GET' => 0, 'HEAD' => 1], null, false, true, null]],
        146 => [[['_route' => 'api_doc', '_controller' => 'api_platform.action.documentation', '_format' => '', '_api_respond' => 'true'], ['_format'], ['GET' => 0, 'HEAD' => 1], null, false, true, null]],
        191 => [[['_route' => 'api_jsonld_context', '_controller' => 'api_platform.jsonld.action.context', '_format' => 'jsonld', '_api_respond' => 'true'], ['shortName', '_format'], ['GET' => 0, 'HEAD' => 1], null, false, true, null]],
        238 => [[['_route' => '_api_/commentaires/{id}{._format}_get', '_controller' => 'api_platform.symfony.main_controller', '_format' => null, '_stateless' => true, '_api_resource_class' => 'App\\Entity\\Commentaire', '_api_operation_name' => '_api_/commentaires/{id}{._format}_get'], ['id', '_format'], ['GET' => 0], null, false, true, null]],
        264 => [
            [['_route' => '_api_/commentaires{._format}_get_collection', '_controller' => 'api_platform.symfony.main_controller', '_format' => null, '_stateless' => true, '_api_resource_class' => 'App\\Entity\\Commentaire', '_api_operation_name' => '_api_/commentaires{._format}_get_collection'], ['_format'], ['GET' => 0], null, false, true, null],
            [['_route' => '_api_/commentaires{._format}_post', '_controller' => 'api_platform.symfony.main_controller', '_format' => null, '_stateless' => true, '_api_resource_class' => 'App\\Entity\\Commentaire', '_api_operation_name' => '_api_/commentaires{._format}_post'], ['_format'], ['POST' => 0], null, false, true, null],
        ],
        305 => [
            [['_route' => '_api_/commentaires/{id}{._format}_patch', '_controller' => 'api_platform.symfony.main_controller', '_format' => null, '_stateless' => true, '_api_resource_class' => 'App\\Entity\\Commentaire', '_api_operation_name' => '_api_/commentaires/{id}{._format}_patch'], ['id', '_format'], ['PATCH' => 0], null, false, true, null],
            [['_route' => '_api_/commentaires/{id}{._format}_delete', '_controller' => 'api_platform.symfony.main_controller', '_format' => null, '_stateless' => true, '_api_resource_class' => 'App\\Entity\\Commentaire', '_api_operation_name' => '_api_/commentaires/{id}{._format}_delete'], ['id', '_format'], ['DELETE' => 0], null, false, true, null],
        ],
        325 => [
            [['_route' => 'app_commentaire_getcommentaire', '_controller' => 'App\\Controller\\CommentaireController::getCommentaire'], ['id'], ['GET' => 0], null, false, true, null],
            [['_route' => 'app_commentaire_updatecommentaire', '_controller' => 'App\\Controller\\CommentaireController::updateCommentaire'], ['id'], ['PUT' => 0], null, false, true, null],
            [['_route' => 'app_commentaire_deletecommentaire', '_controller' => 'App\\Controller\\CommentaireController::deleteCommentaire'], ['id'], ['DELETE' => 0], null, false, true, null],
        ],
        335 => [
            [['_route' => 'app_commentaire_listcommentaires', '_controller' => 'App\\Controller\\CommentaireController::listCommentaires'], [], ['GET' => 0], null, false, false, null],
            [['_route' => 'app_commentaire_createcommentaire', '_controller' => 'App\\Controller\\CommentaireController::createCommentaire'], [], ['POST' => 0], null, false, false, null],
        ],
        378 => [[['_route' => '_api_/clubs/{id}{._format}_get', '_controller' => 'api_platform.symfony.main_controller', '_format' => null, '_stateless' => true, '_api_resource_class' => 'App\\Entity\\Club', '_api_operation_name' => '_api_/clubs/{id}{._format}_get'], ['id', '_format'], ['GET' => 0], null, false, true, null]],
        404 => [
            [['_route' => '_api_/clubs{._format}_get_collection', '_controller' => 'api_platform.symfony.main_controller', '_format' => null, '_stateless' => true, '_api_resource_class' => 'App\\Entity\\Club', '_api_operation_name' => '_api_/clubs{._format}_get_collection'], ['_format'], ['GET' => 0], null, false, true, null],
            [['_route' => '_api_/clubs{._format}_post', '_controller' => 'api_platform.symfony.main_controller', '_format' => null, '_stateless' => true, '_api_resource_class' => 'App\\Entity\\Club', '_api_operation_name' => '_api_/clubs{._format}_post'], ['_format'], ['POST' => 0], null, false, true, null],
        ],
        445 => [
            [['_route' => '_api_/clubs/{id}{._format}_patch', '_controller' => 'api_platform.symfony.main_controller', '_format' => null, '_stateless' => true, '_api_resource_class' => 'App\\Entity\\Club', '_api_operation_name' => '_api_/clubs/{id}{._format}_patch'], ['id', '_format'], ['PATCH' => 0], null, false, true, null],
            [['_route' => '_api_/clubs/{id}{._format}_delete', '_controller' => 'api_platform.symfony.main_controller', '_format' => null, '_stateless' => true, '_api_resource_class' => 'App\\Entity\\Club', '_api_operation_name' => '_api_/clubs/{id}{._format}_delete'], ['id', '_format'], ['DELETE' => 0], null, false, true, null],
        ],
        465 => [
            [['_route' => 'app_club_getclub', '_controller' => 'App\\Controller\\ClubController::getClub'], ['id'], ['GET' => 0], null, false, true, null],
            [['_route' => 'app_club_updateclub', '_controller' => 'App\\Controller\\ClubController::updateClub'], ['id'], ['PUT' => 0], null, false, true, null],
            [['_route' => 'app_club_deleteclub', '_controller' => 'App\\Controller\\ClubController::deleteClub'], ['id'], ['DELETE' => 0], null, false, true, null],
        ],
        475 => [
            [['_route' => 'app_club_listclubs', '_controller' => 'App\\Controller\\ClubController::listClubs'], [], ['GET' => 0], null, false, false, null],
            [['_route' => 'app_club_createclub', '_controller' => 'App\\Controller\\ClubController::createClub'], [], ['POST' => 0], null, false, false, null],
        ],
        515 => [[['_route' => '_api_errors', '_controller' => 'api_platform.symfony.main_controller', '_format' => null, '_stateless' => true, '_api_resource_class' => 'ApiPlatform\\State\\ApiResource\\Error', '_api_operation_name' => '_api_errors'], ['status', '_format'], ['GET' => 0], null, false, true, null]],
        561 => [[['_route' => '_api_/evenements/{id}{._format}_get', '_controller' => 'api_platform.symfony.main_controller', '_format' => null, '_stateless' => true, '_api_resource_class' => 'App\\Entity\\Evenement', '_api_operation_name' => '_api_/evenements/{id}{._format}_get'], ['id', '_format'], ['GET' => 0], null, false, true, null]],
        587 => [
            [['_route' => '_api_/evenements{._format}_get_collection', '_controller' => 'api_platform.symfony.main_controller', '_format' => null, '_stateless' => true, '_api_resource_class' => 'App\\Entity\\Evenement', '_api_operation_name' => '_api_/evenements{._format}_get_collection'], ['_format'], ['GET' => 0], null, false, true, null],
            [['_route' => '_api_/evenements{._format}_post', '_controller' => 'api_platform.symfony.main_controller', '_format' => null, '_stateless' => true, '_api_resource_class' => 'App\\Entity\\Evenement', '_api_operation_name' => '_api_/evenements{._format}_post'], ['_format'], ['POST' => 0], null, false, true, null],
        ],
        628 => [
            [['_route' => '_api_/evenements/{id}{._format}_patch', '_controller' => 'api_platform.symfony.main_controller', '_format' => null, '_stateless' => true, '_api_resource_class' => 'App\\Entity\\Evenement', '_api_operation_name' => '_api_/evenements/{id}{._format}_patch'], ['id', '_format'], ['PATCH' => 0], null, false, true, null],
            [['_route' => '_api_/evenements/{id}{._format}_delete', '_controller' => 'api_platform.symfony.main_controller', '_format' => null, '_stateless' => true, '_api_resource_class' => 'App\\Entity\\Evenement', '_api_operation_name' => '_api_/evenements/{id}{._format}_delete'], ['id', '_format'], ['DELETE' => 0], null, false, true, null],
        ],
        648 => [
            [['_route' => 'app_evenement_getevenement', '_controller' => 'App\\Controller\\EvenementController::getEvenement'], ['id'], ['GET' => 0], null, false, true, null],
            [['_route' => 'app_evenement_updateevenement', '_controller' => 'App\\Controller\\EvenementController::updateEvenement'], ['id'], ['PUT' => 0], null, false, true, null],
            [['_route' => 'app_evenement_deleteevenement', '_controller' => 'App\\Controller\\EvenementController::deleteEvenement'], ['id'], ['DELETE' => 0], null, false, true, null],
        ],
        658 => [
            [['_route' => 'app_evenement_listevenements', '_controller' => 'App\\Controller\\EvenementController::listEvenements'], [], ['GET' => 0], null, false, false, null],
            [['_route' => 'app_evenement_createevenement', '_controller' => 'App\\Controller\\EvenementController::createEvenement'], [], ['POST' => 0], null, false, false, null],
        ],
        697 => [
            [['_route' => '_api_validation_errors_problem', '_controller' => 'api_platform.symfony.main_controller', '_format' => null, '_stateless' => true, '_api_resource_class' => 'ApiPlatform\\Validator\\Exception\\ValidationException', '_api_operation_name' => '_api_validation_errors_problem'], ['id'], ['GET' => 0], null, false, true, null],
            [['_route' => '_api_validation_errors_hydra', '_controller' => 'api_platform.symfony.main_controller', '_format' => null, '_stateless' => true, '_api_resource_class' => 'ApiPlatform\\Validator\\Exception\\ValidationException', '_api_operation_name' => '_api_validation_errors_hydra'], ['id'], ['GET' => 0], null, false, true, null],
            [['_route' => '_api_validation_errors_jsonapi', '_controller' => 'api_platform.symfony.main_controller', '_format' => null, '_stateless' => true, '_api_resource_class' => 'ApiPlatform\\Validator\\Exception\\ValidationException', '_api_operation_name' => '_api_validation_errors_jsonapi'], ['id'], ['GET' => 0], null, false, true, null],
        ],
        747 => [[['_route' => '_api_/utilisateurs/{id}{._format}_get', '_controller' => 'api_platform.symfony.main_controller', '_format' => null, '_stateless' => true, '_api_resource_class' => 'App\\Entity\\Utilisateur', '_api_operation_name' => '_api_/utilisateurs/{id}{._format}_get'], ['id', '_format'], ['GET' => 0], null, false, true, null]],
        773 => [
            [['_route' => '_api_/utilisateurs{._format}_get_collection', '_controller' => 'api_platform.symfony.main_controller', '_format' => null, '_stateless' => true, '_api_resource_class' => 'App\\Entity\\Utilisateur', '_api_operation_name' => '_api_/utilisateurs{._format}_get_collection'], ['_format'], ['GET' => 0], null, false, true, null],
            [['_route' => '_api_/utilisateurs{._format}_post', '_controller' => 'api_platform.symfony.main_controller', '_format' => null, '_stateless' => true, '_api_resource_class' => 'App\\Entity\\Utilisateur', '_api_operation_name' => '_api_/utilisateurs{._format}_post'], ['_format'], ['POST' => 0], null, false, true, null],
        ],
        814 => [
            [['_route' => '_api_/utilisateurs/{id}{._format}_patch', '_controller' => 'api_platform.symfony.main_controller', '_format' => null, '_stateless' => true, '_api_resource_class' => 'App\\Entity\\Utilisateur', '_api_operation_name' => '_api_/utilisateurs/{id}{._format}_patch'], ['id', '_format'], ['PATCH' => 0], null, false, true, null],
            [['_route' => '_api_/utilisateurs/{id}{._format}_delete', '_controller' => 'api_platform.symfony.main_controller', '_format' => null, '_stateless' => true, '_api_resource_class' => 'App\\Entity\\Utilisateur', '_api_operation_name' => '_api_/utilisateurs/{id}{._format}_delete'], ['id', '_format'], ['DELETE' => 0], null, false, true, null],
        ],
        831 => [[['_route' => 'app_utilisateur_getutilisateur', '_controller' => 'App\\Controller\\UtilisateurController::getUtilisateur'], ['id'], ['GET' => 0], null, false, true, null]],
        840 => [
            [['_route' => 'app_utilisateur_listutilisateurs', '_controller' => 'App\\Controller\\UtilisateurController::listUtilisateurs'], [], ['GET' => 0], null, false, false, null],
            [['_route' => 'app_utilisateur_createutilisateur', '_controller' => 'App\\Controller\\UtilisateurController::createUtilisateur'], [], ['POST' => 0], null, false, false, null],
        ],
        879 => [
            [['_route' => '_preview_error', '_controller' => 'error_controller::preview', '_format' => 'html'], ['code', '_format'], null, null, false, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
