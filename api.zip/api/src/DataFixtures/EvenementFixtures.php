<?php

namespace App\DataFixtures;

use App\Entity\Evenement;
use App\Entity\Club;
use App\Entity\Utilisateur;
use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Persistence\ObjectManager;
use Doctrine\Common\DataFixtures\DependentFixtureInterface;

class EvenementFixtures extends Fixture implements DependentFixtureInterface
{
    public function load(ObjectManager $manager): void
    {
        // Fetch existing clubs and users
        $clubs = $manager->getRepository(Club::class)->findAll();
        $users = $manager->getRepository(Utilisateur::class)->findAll();

        if (empty($clubs) || empty($users)) {
            throw new \Exception('Ensure you have created Clubs and Users before Evenements');
        }

        $evenement1 = new Evenement();
        $evenement1->setTitre('Atelier Photo')
                   ->setDescription('Atelier de photographie pour débutants')
                   ->setLieu('Studio Créatif')
                   ->setDate(new \DateTime('+1 month'))
                   ->setImage('photo_workshop.jpg')
                   ->setDateCreation(new \DateTime())
                   ->setClub($clubs[0])
                   ->setOrganisateur($users[0]);

        $evenement2 = new Evenement();
        $evenement2->setTitre('Exploration VR')
                   ->setDescription('Découverte des dernières technologies VR')
                   ->setLieu('Centre Technologique')
                   ->setDate(new \DateTime('+2 months'))
                   ->setImage('vr_event.jpg')
                   ->setDateCreation(new \DateTime())
                   ->setClub($clubs[1])
                   ->setOrganisateur($users[1]);

        $manager->persist($evenement1);
        $manager->persist($evenement2);
        $manager->flush();
    }

    public function getDependencies(): array
    {
        return [
            ClubFixtures::class,
            UtilisateurFixtures::class
        ];
    }
}
