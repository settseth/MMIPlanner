<?php
// src/Controller/SecurityController.php
namespace App\Controller;

use App\Entity\Utilisateur;
use App\Repository\UtilisateurRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Security\Http\Authentication\AuthenticationUtils;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\PasswordHasher\Hasher\UserPasswordHasherInterface;

class SecurityController extends AbstractController
{
    private $userRepository;
    private $passwordHasher;
    private $entityManager;

    public function __construct(
        UtilisateurRepository $userRepository,
        UserPasswordHasherInterface $passwordHasher,
        EntityManagerInterface $entityManager
    ) {
        $this->userRepository = $userRepository;
        $this->passwordHasher = $passwordHasher;
        $this->entityManager = $entityManager;
    }

    #[Route('/api/login', name: 'app_login', methods: ['POST'])]
    public function login(Request $request): JsonResponse
    {
        $data = json_decode($request->getContent(), true);

        // Validate input
        if (!isset($data['email']) || !isset($data['motdepasse'])) {
            return new JsonResponse(['error' => 'Missing email or password'], 400);
        }

        // Find user by email
        $user = $this->userRepository->findOneBy(['email' => $data['email']]);
        
        // Check if user exists and password is valid
        if (!$user || !$this->passwordHasher->isPasswordValid($user, $data['motdepasse'])) {
            return new JsonResponse(['error' => 'Invalid credentials'], 401);
        }

        // Return user details
        return new JsonResponse([
            'message' => 'Login successful',
            'user' => [
                'id' => $user->getId(),
                'email' => $user->getEmail(),
                'roles' => $user->getRoles(),
                'prenom' => $user->getPrenom(),
                'nom' => $user->getNom()
            ]
        ]);
    }

    #[Route('/api/register', name: 'app_register', methods: ['POST'])]
    public function register(Request $request): JsonResponse
    {
        $data = json_decode($request->getContent(), true);

        // Validate required fields
        $requiredFields = ['email', 'motdepasse', 'prenom', 'nom'];
        foreach ($requiredFields as $field) {
            if (!isset($data[$field])) {
                return new JsonResponse(['error' => "Missing required field: $field"], 400);
            }
        }

        // Check if user already exists
        if ($this->userRepository->findOneBy(['email' => $data['email']])) {
            return new JsonResponse([
                'error' => 'Registration failed',
                'details' => 'User with this email already exists'
            ], 409);
        }

        // Create new user
        $user = new Utilisateur();
        $user->setEmail($data['email']);
        $user->setPrenom($data['prenom']);
        $user->setNom($data['nom']);
        $user->setEstactif(true);
        $user->setRoles(['ROLE_USER']);

        // Hash password
        $hashedPassword = $this->passwordHasher->hashPassword($user, $data['motdepasse']);
        $user->setMotdepasse($hashedPassword);

        try {
            $this->entityManager->persist($user);
            $this->entityManager->flush();
        } catch (\Exception $e) {
            return new JsonResponse([
                'error' => 'Registration failed',
                'details' => $e->getMessage()
            ], 500);
        }

        return new JsonResponse([
            'message' => 'User registered successfully',
            'user' => [
                'email' => $user->getUserIdentifier(),
                'prenom' => $user->getPrenom(),
                'nom' => $user->getNom(),
                'roles' => $user->getRoles()
            ]
        ], 201);
    }

    // Logout is handled client-side in a stateless API by removing the token
    // No server-side logout endpoint is needed
}