<?php

namespace App\DataFixtures;

use App\Entity\Club;
use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Persistence\ObjectManager;

class ClubFixtures extends Fixture
{
    public function load(ObjectManager $manager): void
    {
        $club1 = new Club();
        $club1->setNom('Club de Photographie')
              ->setDescription('Un club de photographie')
              ->setImage('photo.jpg')
              ->setDateCreation(new \DateTime());

        $club2 = new Club();
        $club2->setNom('Club de VR')
              ->setDescription('Club de VR')
              ->setImage('vr.jpg')
              ->setDateCreation(new \DateTime());

        $manager->persist($club1);
        $manager->persist($club2);
        $manager->flush();
    }
}
